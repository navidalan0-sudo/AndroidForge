CLUB PRESIDENT — ANDROID INSTALLABLE APP

This package turns the game into an installable Progressive Web App (PWA). It is not a signed APK.

INSTALL ON ANDROID:
1. Extract this ZIP.
2. Upload the contents of the club-president-app folder to an HTTPS static host (for example, Netlify Drop).
3. Open the resulting HTTPS website in Chrome on your Android phone.
4. Open Chrome menu (three dots) and choose "Install app" or "Add to Home screen".
5. Confirm. Club President will appear on your home screen and open in its own app window.

The service worker caches the game so it can reopen offline after the first successful load. Career saves remain in this browser/device storage; use the in-game save button and avoid clearing Chrome site data.

For a true APK, this PWA would need to be wrapped and signed separately.
