CLUB PRESIDENT — ANDROID PROJECT

This is an Android Studio/Code on the Go project wrapper around the supplied Club President game.
It is a PROJECT SOURCE ZIP, not a compiled APK.

WHAT IS INCLUDED
- app/src/main/assets/index.html: the game bundled inside the app
- Android WebView launcher, landscape/full-screen mode
- Local browser storage enabled for career saves
- No INTERNET permission; the wrapper itself does not need network access to run
- Club President launcher icon and app name

BUILD ON YOUR ANDROID PHONE
1. Install Code on the Go from its official site: https://appdevforall.org/code-on-the-go/
2. Extract this ZIP to a normal folder on your phone.
3. In Code on the Go, open/import the extracted ClubPresident project folder (the folder containing settings.gradle).
4. Allow its initial toolchain setup. This setup may need internet and several GB of free storage; the finished game itself is designed to run offline.
5. Wait for Gradle sync to finish, then choose the app's assembleDebug/build APK action.
6. Find the generated debug APK in app/build/outputs/apk/debug/ and install it.

NOTES
- This project targets Android 6.0+ and uses landscape orientation.
- Career saves are stored in the app's local WebView storage. Uninstalling the app or clearing its app data can erase saves; export/backup options depend on the game itself.
- The supplied HTML game is included as-is. This wrapper does not add new football simulation features.
- If Code on the Go reports an SDK/toolchain version mismatch, use its project migration/toolchain guidance before building.
